﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _20._102k_Cherepanov_4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadData.ItemsSource = Helper.GetContext().Group.ToList();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = Helper.GetContext().Group.Where(p => p.Speciality.Title == "15.02.09 Аддитивные технологии").OrderBy(p=> p.Title);
                int count = Helper.GetContext().Group.Where(p => p.Speciality.Title == "15.02.09 Аддитивные технологии").Count();
                LoadData.ItemsSource = result.ToList();
                if (count < 1)
                {
                    MessageBox.Show("Элементы не найдены!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
          
        }
    }
}
