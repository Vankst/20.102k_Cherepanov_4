﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _20._102k_Cherepanov_4.Entity;

namespace _20._102k_Cherepanov_4
{
    class Helper
    {
        private static Entities s_entites;

        public static Entities GetContext()
        {
            if (s_entites == null)
            {
                s_entites = new Entities();
            }
            return s_entites;
        }
    }
}
